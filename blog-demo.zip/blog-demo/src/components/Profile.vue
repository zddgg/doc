<script setup>

</script>

<template>
  <div style="width: 100%">
    <a-card>
      <div style="display: flex; justify-content: center;">
        <a-avatar :size="64">
          <img
              alt="avatar"
              src="https://p1-arco.byteimg.com/tos-cn-i-uwbnlip3yd/3ee5f13fb09879ecb5185e440cef6eb9.png~tplv-uwbnlip3yd-webp.webp"
          />
        </a-avatar>
      </div>
      <div style="display: flex; justify-content: center; margin-top: 1rem">
        <span style="font-size: 1.5rem">
          HiHiHiHi
        </span>
      </div>
      <div style="display: flex; justify-content: center; margin-top: 0.5rem">
        <span style="font-size: 1rem">
          HiHiHiHi
        </span>
      </div>
      <div style="display: flex; justify-content: space-between; margin-top: 2rem">
        <div>Github</div>
        <div>Gitee</div>
        <div>QQ</div>
      </div>
    </a-card>
  </div>
</template>

<style scoped>

</style>