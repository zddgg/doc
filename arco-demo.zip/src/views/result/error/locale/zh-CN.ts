export default {
  'menu.result.error': '失败页',
  'error.result.title': '提交失败',
  'error.result.subTitle': '表单提交失败，请重试。',
  'error.result.goBack': '回到首页',
  'error.result.retry': '返回修改',
  'error.detailTitle': '错误详情',
  'error.detailLine.record': '当前域名未备案，备案流程请查看：',
  'error.detailLine.record.link': '备案流程',
  'error.detailLine.auth': '你的用户组不具有进行此操作的权限；',
};
