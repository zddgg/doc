export default {
  'messageBox.tab.title.message': '消息',
  'messageBox.tab.title.notice': '通知',
  'messageBox.tab.title.todo': '待办',
  'messageBox.tab.button': '清空',
  'messageBox.allRead': '全部已读',
  'messageBox.viewMore': '查看更多',
  'messageBox.noContent': '暂无内容',
  'messageBox.switchRoles': '切换角色',
  'messageBox.userCenter': '用户中心',
  'messageBox.userSettings': '用户设置',
  'messageBox.logout': '登出登录',
};
